# Núcleo — Hito 3

Plataforma educativa de Sistemas Operativos. Versión local: no requiere instalación de paquetes, cuenta, base de datos ni clave de API.

## Abrir

Desde esta carpeta, ejecutar:

```sh
python3 -m http.server 8080 --bind 127.0.0.1
```

Abrir http://127.0.0.1:8080. En Windows puede usarse `py -m http.server 8080 --bind 127.0.0.1` si Python está instalado. También puede abrirse `index.html` directamente, aunque el guardado local de archivos abiertos con file:// depende del navegador. Para una experiencia consistente, usar el servidor local y el mismo puerto.

## Incluido en el Hito 3

- Ruta de seis lecciones con concepto, analogía, demostración manipulable y dos preguntas por lección.
- Explorador conceptual de CPU, RAM, almacenamiento y sistema operativo.
- Recorrido guiado al abrir una aplicación.
- Laboratorio de CPU: FCFS, SJF, Round Robin y Prioridad.
- Procesos configurables (hasta 8), llegada, duración y prioridad. Tocar el identificador permite editarlo.
- Reproducción, pausa, paso, retroceso, reinicio y velocidades visuales.
- Cola de listos, estados, tiempo restante, línea de tiempo y explicación de cada instante.
- Predicción del siguiente estado, resultados y comparación con los cuatro algoritmos.
- Guía del laboratorio y diccionario con búsqueda.
- Progreso y puntos en localStorage. Se concede una sola vez 100 XP por lección y 40 XP por la primera simulación completada.
- Diseño adaptable, navegación por teclado, etiquetas accesibles y respeto a movimiento reducido.

## Reglas del modelo

Una CPU, una ráfaga por proceso, duración conocida, sin entrada/salida, espera por memoria ni costo de cambio de contexto. La RAM del explorador es conceptual; no es un asignador implementado.

FCFS atiende por llegada. SJF y Prioridad no interrumpen. Mayor número = mayor prioridad. Empates: llegada y después orden de registro. Round Robin inserta nuevas llegadas antes de reencolar al proceso cuyo quantum terminó. El estado t muestra quién ejecutará el intervalo [t, t+1); la línea de tiempo contiene únicamente intervalos ya ejecutados.

Retorno = finalización − llegada. Espera = retorno − duración. Los tiempos pertenecen al reloj simulado y no dependen de la velocidad visual.

## Archivos

- `index.html`: estructura y navegación.
- `styles.css`: identidad visual y adaptación de tamaños.
- `lessons.js`: contenido educativo y glosario.
- `engine.js`: motor de planificación puro, independiente de la interfaz.
- `app.js`: interacción, progreso y presentación de resultados.
- `tests/engine.test.cjs`: casos conocidos e invariantes en 400 simulaciones.

Verificar el motor con Node.js:

```sh
node --test tests/engine.test.cjs
```

## Datos y conexión

El progreso se guarda solamente en el navegador y origen actuales, con la clave `nucleo.progress.v1`. Borrar los datos del sitio borra ese progreso. Si el almacenamiento no está disponible, la aplicación funciona con progreso temporal en la sesión.

La única dependencia remota es la carga opcional de fuentes de Google Fonts. Si no hay conexión, se usa la tipografía del sistema y las funciones siguen disponibles. No hay llamadas a OpenAI, Supabase, analítica ni servidores de aplicación.

## Siguientes entregas

Hito 4: asignación/liberación de memoria e integración con CPU, paginación, archivos simulados, tutor OpenAI y cuentas/progreso sincronizado con Supabase.

Hito 5: validación con estudiantes, ajustes de contenido y accesibilidad, publicación y documentación final.

El 50% es la meta de alcance de la entrega, no un porcentaje de aprendizaje ni una medición automática de avance de desarrollo.
